sap.ui.define([
  'sap/ui/core/UIComponent',
  'sap/ui/core/ComponentSupport'
], UIComponent => UIComponent.extend('cc.ase.poker.table.Component', {
  metadata: {
    manifest: 'json'
  }
}))
